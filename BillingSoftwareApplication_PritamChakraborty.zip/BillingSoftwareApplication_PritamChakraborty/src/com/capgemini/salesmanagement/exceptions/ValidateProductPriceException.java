package com.capgemini.salesmanagement.exceptions;

public class ValidateProductPriceException extends Exception{

	public ValidateProductPriceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ValidateProductPriceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ValidateProductPriceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ValidateProductPriceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ValidateProductPriceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
