package com.capgemini.salesmanagement.dao;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.util.CollectionUtil;


public class SaleDAO implements ISaleDAO{
	public HashMap<Integer,Sale> insertSaleDetails(Sale sale){
		save(sale);
		/* return new HashMap<Integer,Sale>(CollectionUtil.sales.hashCode()); */
		return CollectionUtil.getCollection();
	}
	@Override
	public Sale save(Sale sale) {
		CollectionUtil.sales.put(sale.getSaleId() ,sale);
		sale.setSaleId((int) (Math.random()*1000));
		return sale;
	}
}
