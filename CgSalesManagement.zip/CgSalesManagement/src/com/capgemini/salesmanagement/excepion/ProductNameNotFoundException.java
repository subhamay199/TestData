package com.capgemini.salesmanagement.excepion;

public class ProductNameNotFoundException extends Exception {

	public ProductNameNotFoundException() {
		super();
	}

	public ProductNameNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public ProductNameNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public ProductNameNotFoundException(String message) {
		super(message);
	}

	public ProductNameNotFoundException(Throwable cause) {
		super(cause);
	}

}
