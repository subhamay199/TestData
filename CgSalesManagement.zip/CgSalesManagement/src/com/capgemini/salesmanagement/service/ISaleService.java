package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.excepion.ProductNameNotFoundException;
import com.capgemini.salesmanagement.exception.InvalidProductCode;
import com.capgemini.salesmanagement.exception.InvalidProductPriceExcxeption;
import com.capgemini.salesmanagement.exception.InvalidQuantity;
import com.capgemini.salesmanagement.exception.ProductNotFoundException;

public interface ISaleService {
	public HashMap<Integer,Sale>insertSalesDetails(Sale sale);
	public boolean validateProductCode(int productid) throws InvalidProductCode;
	boolean validateQuantity(int qty) throws InvalidQuantity;
	public boolean validateProductCat(String prodCat) throws ProductNotFoundException;
	public boolean vaildateProductName(String prodName) throws ProductNameNotFoundException;
	public boolean validateProductPrice(float price) throws InvalidProductPriceExcxeption;
}
