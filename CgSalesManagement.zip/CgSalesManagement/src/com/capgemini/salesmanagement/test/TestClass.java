package com.capgemini.salesmanagement.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.excepion.ProductNameNotFoundException;
import com.capgemini.salesmanagement.exception.InvalidProductCode;
import com.capgemini.salesmanagement.exception.InvalidProductPriceExcxeption;
import com.capgemini.salesmanagement.exception.InvalidQuantity;
import com.capgemini.salesmanagement.exception.ProductNotFoundException;
import com.capgemini.salesmanagement.service.SaleService;
import com.capgemini.salesmanagement.util.CollectionUtil;


public class TestClass {
public static SaleService services;
@BeforeClass
public static void SetUpTestEnv() {
		services=new SaleService();
}
@Before
public void SetUpTestData() {
	Sale sale=new Sale();
	CollectionUtil.sales.put(sale.getProdCode(),sale);
}
@Test(expected=InvalidProductCode.class)
public void TestGetProductCodeforInvalidValidateProductCode()throws InvalidProductCode{
	boolean actualproductId=services.validateProductCode(1005);
}
@Test
public void TestGetProductCodeforValidValidateProductCode()throws InvalidProductCode{
	boolean actualproductId=services.validateProductCode(1004);
	boolean  expectedproductId=true;
	Assert.assertEquals(expectedproductId, actualproductId);
}
@Test(expected=InvalidQuantity.class)
public void TestGetProductForInvalidValidateQuantity()throws InvalidQuantity{
	boolean expectedquantity=services.validateQuantity(35);
}
@Test
public void TestGetProductForValidValidateQuantity()throws InvalidQuantity{
	boolean expectectedquantity=services.validateQuantity(4);
	boolean  actualquantity=true;
	Assert.assertEquals(expectectedquantity, actualquantity);
}
@Test(expected=ProductNotFoundException.class)
public void TestGetProductCodeforInvalidValidateProductCat()throws ProductNotFoundException{
boolean returnedoutput=services.validateProductCat("Game");
}
@Test
public void TestGetProductCodeforValidValidateProductCat()throws ProductNotFoundException{
	boolean returnedoutput=services.validateProductCat("electronics");
	boolean expectedoutput=true;
	Assert.assertEquals(returnedoutput,expectedoutput);
}
@Test(expected=ProductNameNotFoundException.class)
public void TestGetProductCodeforInvalidValidateProductName() throws ProductNameNotFoundException {
	boolean returnedoutput=services.vaildateProductName("mobile");
}
@Test
public void TestGetProductCodeforValidValidateProductName() throws ProductNameNotFoundException {
	boolean returnedoutput=services.vaildateProductName("tv");
	boolean expectedoutput=true;
	Assert.assertEquals(returnedoutput, expectedoutput);
}
@Test(expected=InvalidProductPriceExcxeption.class)
public void TestGetProductCodeforInvalidValidatePrice() throws InvalidProductPriceExcxeption {
	boolean returnoutput=services.validateProductPrice(100);
}
@Test
public void TestGetProductCodeforValidValidatePrice() throws InvalidProductPriceExcxeption {
	boolean returnoutput=services.validateProductPrice(300);
	boolean expectedoutput=true;
	Assert.assertEquals(returnoutput,expectedoutput);
}
@After
public void tearDownTestData() {
	 CollectionUtil.sales.clear();
}
@AfterClass
public static void tearDownTestEnv() {
	services=null;
}
}
