package com.capgemini.salesmanagement.exception;

public class InvalidProductCode extends Exception {

	public InvalidProductCode() {
		super();
	}

	public InvalidProductCode(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);	
	}

	public InvalidProductCode(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidProductCode(String message) {
		super(message);
	}

	public InvalidProductCode(Throwable cause) {
		super(cause);
	}

}
