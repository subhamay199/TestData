package com.cg.mra.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mra.exceptions.AccountNotFoundException;
import com.cg.mra.exceptions.InvalidMobileNumberException;
import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MobileRechargeTest {
	private static AccountService services; 
	
	@BeforeClass
	public static void setUpTestEnv() {
		services=new AccountServiceImpl();
	}
	
	@Before
	public void SetUpTestData() {
		Account account=new Account();
	}
	
	@Test(expected=InvalidMobileNumberException.class)
	public void testGetAccountDetailsForInvalidMobileNo() throws InvalidMobileNumberException {
		Account expectedDetails=services.getAccountDetails("900000045");
	}
	@AfterClass
	public static void tearDownTestData() {
	services=null;
	}
}
